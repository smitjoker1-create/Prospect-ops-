// Prospect Ops — Upgrade v2 (Offline, Detailed)
// Features added: Maintenance tickets + Retainers + WhatsApp summary in Reports.
// Currency = R

const CURRENCY = "R";
const SCORE = { ok: 0, risk: 1, crit: 2 };

const CHECKLIST = [
  { key: "receiving", label: "Receiving: deliveries checked vs invoice (counts & condition)" },
  { key: "dispatch", label: "Dispatch: goods out signed off + paperwork controlled" },
  { key: "returns", label: "Returns/Credits: controlled process + manager approval" },
  { key: "damages", label: "Damages/Write-offs: documented + stored securely" },
  { key: "highvalue_cage", label: "High-value cage: locked, controlled access, key register" },
  { key: "highvalue_counts", label: "High-value counts: frequent cycle counts (daily/weekly)" },
  { key: "tools_security", label: "Tools/Power tools: serials/labels + display security" },
  { key: "access_keys", label: "Keys: controlled list + sign-in/out" },
  { key: "staff_access", label: "Staff access: restricted areas enforced" },
  { key: "cctv", label: "CCTV coverage: blind spots identified + cameras working" },
  { key: "visibility", label: "Visibility: aisles clear; no hiding spots behind bulk stock" },
  { key: "pallet_control", label: "Pallet/bulk: pallet ID/position control + no mystery pallets" },
  { key: "receiving_area", label: "Receiving area: tidy, controlled, no unattended stock" },
  { key: "stockroom_layout", label: "Stockroom layout: labelled zones, clear locations" },
  { key: "bin_locations", label: "Bin/location discipline: stock kept in correct locations" },
  { key: "pricing_labels", label: "Pricing/labels: correct pricing + reduces 'free' items" },
  { key: "cashier_controls", label: "Till/cashier controls: refunds/voids reviewed" },
  { key: "stock_counts", label: "Stock counts: schedule + variance investigated" },
];

const $app = document.getElementById("app");
const $dlg = document.getElementById("dlg");
const $dlgTitle = document.getElementById("dlgTitle");
const $dlgBody = document.getElementById("dlgBody");
const $dlgFoot = document.getElementById("dlgFoot");
const $restoreFile = document.getElementById("restoreFile");

let state = poLoad();
let view = "dashboard";
let selectedVisitId = state.visits?.[0]?.id || null;

bindNav();
bindBackupRestore();
render();

function uid(p){ return `${p}_${Date.now()}_${Math.random().toString(16).slice(2)}`; }
function todayISO(){ return new Date().toISOString().slice(0,10); }
function money(n){ const x=Number(n||0); return `${CURRENCY}${x.toFixed(2)}`; }
function esc(s=""){ return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c])); }

function defaultChecklist(){ const o={}; for(const sec of CHECKLIST) o[sec.key]={status:"ok",note:""}; return o; }

function calcRisk(v){
  const e=v.checklist||{};
  let pts=0;
  const max = CHECKLIST.length*2;
  for(const sec of CHECKLIST){
    const st = e[sec.key]?.status || "ok";
    pts += SCORE[st] ?? 0;
  }
  const pct = max ? pts/max : 0;
  if(pct<=0.25) return {label:"LOW",cls:"low",points:pts,max};
  if(pct<=0.60) return {label:"MEDIUM",cls:"med",points:pts,max};
  return {label:"HIGH",cls:"high",points:pts,max};
}
function badgeRisk(r){ return `<span class="badge ${r.cls}">${r.label} RISK</span>`; }

function ticketBadge(st){
  const s=(st||"open").toLowerCase();
  if(s==="open") return `<span class="badge open">OPEN</span>`;
  if(s==="quoted") return `<span class="badge quoted">QUOTED</span>`;
  if(s==="approved") return `<span class="badge approved">APPROVED</span>`;
  if(s==="done") return `<span class="badge done">DONE</span>`;
  return `<span class="badge open">${esc(s.toUpperCase())}</span>`;
}

function bindNav(){
  document.querySelectorAll(".tab[data-view]").forEach(b=>{
    b.addEventListener("click",()=>{ view=b.dataset.view; setActive(); render(); });
  });
  setActive();
}
function setActive(){
  document.querySelectorAll(".tab[data-view]").forEach(b=>b.classList.toggle("active", b.dataset.view===view));
}

function bindBackupRestore(){
  document.getElementById("btnBackup").onclick=()=>{
    const data=poExport(state);
    const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url;
    a.download=`prospect_ops_backup_${todayISO()}.json`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  };
  document.getElementById("btnRestore").onclick=()=> $restoreFile.click();
  $restoreFile.addEventListener("change", async (e)=>{
    const f=e.target.files?.[0]; if(!f) return;
    try{
      const txt=await f.text();
      state=poImport(JSON.parse(txt));
      poSave(state);
      alert("Restore complete.");
      render();
    }catch(err){
      alert("Restore failed. Select a valid Prospect Ops backup JSON.");
    }finally{
      $restoreFile.value="";
    }
  });
}

function render(){
  if(view==="dashboard") return renderDashboard();
  if(view==="clients") return renderClients();
  if(view==="visits") return renderVisits();
  if(view==="maintenance") return renderMaintenance();
  if(view==="reports") return renderReports();
  if(view==="retainers") return renderRetainers();
}

// ------- Dashboard -------
function renderDashboard(){
  const clients=state.clients.length;
  const visits=state.visits.length;
  const unpaid=state.visits.filter(v=>(v.status||"draft")!=="paid").length;
  const openTickets=state.tickets.filter(t=>(t.status||"open")!=="done").length;
  const monthly=state.retainers.reduce((s,r)=>s+Number(r.monthly||0),0);

  $app.innerHTML = `
    <div class="row space">
      <h1 class="h1">Dashboard</h1>
      <div class="row">
        <button class="btn primary" id="quickClient">Add Client</button>
        <button class="btn primary" id="quickVisit">New Visit</button>
        <button class="btn" id="quickTicket">New Ticket</button>
      </div>
    </div>

    <div class="row" style="margin-top:12px">
      <div class="card" style="flex:1"><div class="muted">Clients</div><div class="kpi">${clients}</div></div>
      <div class="card" style="flex:1"><div class="muted">Visits</div><div class="kpi">${visits}</div></div>
      <div class="card" style="flex:1"><div class="muted">Not Paid</div><div class="kpi">${unpaid}</div></div>
      <div class="card" style="flex:1"><div class="muted">Open Tickets</div><div class="kpi">${openTickets}</div></div>
      <div class="card" style="flex:1"><div class="muted">Monthly Retainers</div><div class="kpi">${money(monthly)}</div></div>
    </div>

    <div class="card" style="margin-top:12px">
      <h2 class="h2">How this upgrade makes you money</h2>
      <div class="notice">
        1) <b>Visit</b> = assessment fee (R800–R1500)<br>
        2) <b>Maintenance</b> tickets = coordination margin / quote tracking<br>
        3) <b>Retainers</b> = recurring income (monthly “keep risk LOW”)
      </div>
    </div>
  `;

  document.getElementById("quickClient").onclick=()=>openClientDialog();
  document.getElementById("quickVisit").onclick=()=>openVisitDialog();
  document.getElementById("quickTicket").onclick=()=>openTicketDialog();
}

// ------- Clients -------
function renderClients(){
  const rows = state.clients.slice().sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).map(c=>`
    <tr>
      <td><strong>${esc(c.name)}</strong><div class="muted">${esc(c.address||"")}</div></td>
      <td>${esc(c.owner||"")}</td>
      <td class="muted">${esc(c.whatsapp||c.phone||"")}</td>
      <td>
        <div class="row">
          <button class="btn small" data-edit="${c.id}">Edit</button>
          <button class="btn small" data-wa="${c.id}">WhatsApp</button>
          <button class="btn small danger" data-del="${c.id}">Delete</button>
        </div>
      </td>
    </tr>
  `).join("");

  $app.innerHTML = `
    <div class="row space">
      <h1 class="h1">Clients</h1>
      <button class="btn primary" id="addClient">Add client</button>
    </div>
    <div class="card" style="margin-top:12px">
      <table class="table">
        <thead><tr><th>Shop</th><th>Owner</th><th>Contact</th><th>Actions</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      ${state.clients.length===0 ? `<div class="notice">Add your first hardware shop.</div>` : ""}
    </div>
  `;

  document.getElementById("addClient").onclick=()=>openClientDialog();

  $app.querySelectorAll("[data-edit]").forEach(b=> b.onclick=()=>{
    openClientDialog(state.clients.find(x=>x.id===b.dataset.edit));
  });

  $app.querySelectorAll("[data-del]").forEach(b=> b.onclick=()=>{
    if(!confirm("Delete this client?")) return;
    const id=b.dataset.del;
    state.clients = state.clients.filter(x=>x.id!==id);
    state.visits = state.visits.map(v=>v.clientId===id?{...v,clientId:""}:v);
    state.tickets = state.tickets.map(t=>t.clientId===id?{...t,clientId:""}:t);
    state.retainers = state.retainers.filter(r=>r.clientId!==id);
    poSave(state); render();
  });

  $app.querySelectorAll("[data-wa]").forEach(b=> b.onclick=()=>{
    const c=state.clients.find(x=>x.id===b.dataset.wa);
    const num=(c?.whatsapp||c?.phone||"").replace(/[^\d+]/g,"");
    if(!num) return alert("Add a WhatsApp/phone number first.");
    const msg=encodeURIComponent("Hi, I'm with Prospect Ops. I help hardware shops reduce stock loss and fix operational issues after-hours/weekends. Can I call you for 5 minutes?");
    window.open(`https://wa.me/${num.replace("+","")}?text=${msg}`, "_blank");
  });
}

// ------- Visits -------
function renderVisits(){
  const clientName = (id)=> state.clients.find(c=>c.id===id)?.name || "—";

  const rows = state.visits.slice().sort((a,b)=>(b.date||"").localeCompare(a.date||"")||(b.createdAt||0)-(a.createdAt||0)).map(v=>{
    const r=calcRisk(v);
    return `
      <tr>
        <td><strong>${esc(v.date||"")}</strong><div class="muted">${esc(v.time||"")}</div></td>
        <td>${esc(clientName(v.clientId))}</td>
        <td>${esc(v.type||"Stock Check")}</td>
        <td>${esc((v.status||"draft").toUpperCase())}</td>
        <td>${badgeRisk(r)} <span class="muted">(${r.points}/${r.max})</span></td>
        <td>${money(v.total||0)}</td>
        <td>
          <div class="row">
            <button class="btn small" data-open="${v.id}">Open</button>
            <button class="btn small" data-report="${v.id}">Report</button>
            <button class="btn small danger" data-del="${v.id}">Delete</button>
          </div>
        </td>
      </tr>
    `;
  }).join("");

  $app.innerHTML = `
    <div class="row space">
      <h1 class="h1">Visits</h1>
      <button class="btn primary" id="addVisit">New visit</button>
    </div>
    <div class="card" style="margin-top:12px">
      <table class="table">
        <thead><tr><th>Date</th><th>Client</th><th>Type</th><th>Status</th><th>Risk</th><th>Total</th><th>Actions</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      ${state.visits.length===0 ? `<div class="notice">Create your first assessment visit.</div>` : ""}
    </div>
  `;

  document.getElementById("addVisit").onclick=()=>openVisitDialog();

  $app.querySelectorAll("[data-open]").forEach(b=> b.onclick=()=> openVisitDialog(state.visits.find(x=>x.id===b.dataset.open)));
  $app.querySelectorAll("[data-del]").forEach(b=> b.onclick=()=>{
    if(!confirm("Delete this visit?")) return;
    state.visits = state.visits.filter(x=>x.id!==b.dataset.del);
    poSave(state); render();
  });
  $app.querySelectorAll("[data-report]").forEach(b=> b.onclick=()=>{
    selectedVisitId=b.dataset.report;
    view="reports"; setActive(); render();
  });
}

// ------- Maintenance -------
function renderMaintenance(){
  const clientName = (id)=> state.clients.find(c=>c.id===id)?.name || "—";
  const rows = state.tickets.slice().sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).map(t=>`
    <tr>
      <td><strong>${esc(clientName(t.clientId))}</strong></td>
      <td>${esc(t.title||"")}<div class="muted">${esc(t.notes||"")}</div></td>
      <td>${esc(t.priority||"")}</td>
      <td>${ticketBadge(t.status)}</td>
      <td>${money(t.quote||0)}</td>
      <td>
        <div class="row">
          <button class="btn small" data-open="${t.id}">Open</button>
          <button class="btn small danger" data-del="${t.id}">Delete</button>
        </div>
      </td>
    </tr>
  `).join("");

  $app.innerHTML = `
    <div class="row space">
      <h1 class="h1">Maintenance</h1>
      <button class="btn primary" id="addTicket">New ticket</button>
    </div>
    <div class="card" style="margin-top:12px">
      <table class="table">
        <thead><tr><th>Client</th><th>Task</th><th>Priority</th><th>Status</th><th>Quote</th><th>Actions</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      ${state.tickets.length===0 ? `<div class="notice">Log issues like locks, cages, lights, doors. Track them to completion.</div>` : ""}
    </div>
  `;

  document.getElementById("addTicket").onclick=()=>openTicketDialog();
  $app.querySelectorAll("[data-open]").forEach(b=> b.onclick=()=> openTicketDialog(state.tickets.find(x=>x.id===b.dataset.open)));
  $app.querySelectorAll("[data-del]").forEach(b=> b.onclick=()=>{
    if(!confirm("Delete this ticket?")) return;
    state.tickets = state.tickets.filter(x=>x.id!==b.dataset.del);
    poSave(state); render();
  });
}

// ------- Reports -------
function renderReports(){
  const v = state.visits.find(x=>x.id===selectedVisitId) || state.visits[0];
  if(!v){
    $app.innerHTML = `<div class="card"><h1 class="h1">Reports</h1><div class="notice">No visits yet. Create a visit first.</div></div>`;
    return;
  }
  selectedVisitId = v.id;
  const client = state.clients.find(c=>c.id===v.clientId);
  const r = calcRisk(v);
  const top = CHECKLIST.map(sec=>({sec,st:(v.checklist?.[sec.key]?.status||"ok"),note:(v.checklist?.[sec.key]?.note||"")}))
    .filter(x=>x.st!=="ok").sort((a,b)=>SCORE[b.st]-SCORE[a.st]).slice(0,7);
  const relatedTickets = state.tickets.filter(t=>t.clientId===v.clientId).slice(0,10);

  $app.innerHTML = `
    <div class="row space" id="printHint">
      <h1 class="h1">Reports</h1>
      <div class="row">
        <select id="visitPick" class="btn" style="padding:8px 10px">
          ${state.visits.slice().sort((a,b)=>(b.date||"").localeCompare(a.date||"")).map(x=>`<option value="${x.id}" ${x.id===v.id?"selected":""}>${esc(x.date||"")} — ${esc(state.clients.find(c=>c.id===x.clientId)?.name||"—")}</option>`).join("")}
        </select>
        <button class="btn" id="btnPrint">Print / Save PDF</button>
        <button class="btn" id="btnWA">WhatsApp summary</button>
      </div>
    </div>

    <section class="card" style="margin-top:12px">
      <div class="row space">
        <div>
          <div class="pills">${badgeRisk(r)} <span class="muted">(${r.points}/${r.max})</span></div>
          <h2 style="margin:8px 0 0;font-size:18px">Prospect Ops — Stock & Maintenance Control</h2>
          <div class="muted">Prepared report</div>
        </div>
        <div style="text-align:right">
          <div><strong>Date:</strong> ${esc(v.date||"")}</div>
          <div><strong>Client:</strong> ${esc(client?.name || "—")}</div>
          <div class="muted">${esc(client?.address || "")}</div>
        </div>
      </div>

      <div class="hr"></div>

      <h3 style="margin:0 0 6px;font-size:15px">Top issues (prioritise)</h3>
      ${top.length===0 ? `<div class="muted">No risks flagged. Great control.</div>` : `
        <ul>
          ${top.map(x => `<li><b>${esc(x.sec.label)}</b> — ${(x.st==="crit")?"CRITICAL":"RISK"} ${x.note?`<span class="muted">(${esc(x.note)})</span>`:""}</li>`).join("")}
        </ul>
      `}

      <div class="hr"></div>

      <h3 style="margin:0 0 6px;font-size:15px">Maintenance tickets</h3>
      ${relatedTickets.length===0 ? `<div class="muted">No tickets logged.</div>` : `
        <ul>
          ${relatedTickets.map(t=>`<li><b>${esc(t.title)}</b> — ${esc((t.status||"open").toUpperCase())} (Quote: ${money(t.quote||0)})</li>`).join("")}
        </ul>
      `}

      <div class="hr"></div>

      <h3 style="margin:0 0 6px;font-size:15px">Invoice</h3>
      <div><strong>Total:</strong> ${money(v.total || 0)}</div>
      ${v.invoiceNotes ? `<div class="muted">${esc(v.invoiceNotes)}</div>` : ""}
      <div class="muted">Payment: EFT / Cash. Prospect Ops.</div>
    </section>
  `;

  document.getElementById("btnPrint").onclick=()=>window.print();
  document.getElementById("visitPick").onchange=(e)=>{ selectedVisitId=e.target.value; render(); };
  document.getElementById("btnWA").onclick=()=>{
    const num=(client?.whatsapp||client?.phone||"").replace(/[^\d+]/g,"");
    if(!num) return alert("Add a WhatsApp/phone number first under Clients.");
    const msg=encodeURIComponent(
      `Prospect Ops Report — ${client?.name||""} (${v.date||""})\n`+
      `Risk: ${r.label} (${r.points}/${r.max})\n`+
      `Top issues: ${top.slice(0,3).map(x=>x.sec.label).join(" | ")}\n`+
      `Invoice: ${money(v.total||0)}\n`+
      `Reply YES to book monthly control visits.`
    );
    window.open(`https://wa.me/${num.replace("+","")}?text=${msg}`, "_blank");
  };
}

// ------- Retainers -------
function renderRetainers(){
  const clientName = (id)=> state.clients.find(c=>c.id===id)?.name || "—";
  const rows = state.retainers.slice().sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).map(r=>`
    <tr>
      <td><strong>${esc(clientName(r.clientId))}</strong></td>
      <td>${esc(r.plan||"Monthly Control")}</td>
      <td>${money(r.monthly||0)}</td>
      <td class="muted">${esc(r.nextDate||"")}</td>
      <td>
        <div class="row">
          <button class="btn small" data-open="${r.id}">Edit</button>
          <button class="btn small danger" data-del="${r.id}">Delete</button>
        </div>
      </td>
    </tr>
  `).join("");
  const total = state.retainers.reduce((s,r)=>s+Number(r.monthly||0),0);

  $app.innerHTML = `
    <div class="row space">
      <h1 class="h1">Retainers</h1>
      <div class="row">
        <div class="notice" style="padding:8px 10px">Total monthly: <b>${money(total)}</b></div>
        <button class="btn primary" id="addRet">New retainer</button>
      </div>
    </div>
    <div class="card" style="margin-top:12px">
      <table class="table">
        <thead><tr><th>Client</th><th>Plan</th><th>Monthly</th><th>Next visit</th><th>Actions</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      ${state.retainers.length===0 ? `<div class="notice">Offer retainers after the first report: “I come back monthly and keep this risk LOW.”</div>` : ""}
    </div>
  `;

  document.getElementById("addRet").onclick=()=>openRetainerDialog();
  $app.querySelectorAll("[data-open]").forEach(b=> b.onclick=()=>openRetainerDialog(state.retainers.find(x=>x.id===b.dataset.open)));
  $app.querySelectorAll("[data-del]").forEach(b=> b.onclick=()=>{
    if(!confirm("Delete this retainer?")) return;
    state.retainers = state.retainers.filter(x=>x.id!==b.dataset.del);
    poSave(state); render();
  });
}

// ------- Dialog framework + forms -------
function openDlg(title, bodyHTML, footHTML){
  $dlgTitle.textContent = title;
  $dlgBody.innerHTML = bodyHTML;
  $dlgFoot.innerHTML = footHTML;
  $dlg.showModal();
}

function openClientDialog(client){
  const isEdit=!!client?.id;
  const c=client?{...client}:{id:uid("c"),createdAt:Date.now(),name:"",owner:"",whatsapp:"",phone:"",address:"",notes:""};

  openDlg(isEdit?"Edit client":"Add client",`
    <div class="field"><label>Shop name</label><input id="c_name" value="${esc(c.name)}"></div>
    <div class="row">
      <div class="field" style="flex:1"><label>Owner/manager</label><input id="c_owner" value="${esc(c.owner)}"></div>
      <div class="field" style="flex:1"><label>WhatsApp</label><input id="c_whatsapp" placeholder="+27..." value="${esc(c.whatsapp)}"></div>
    </div>
    <div class="row">
      <div class="field" style="flex:1"><label>Phone</label><input id="c_phone" value="${esc(c.phone)}"></div>
      <div class="field" style="flex:2"><label>Address</label><input id="c_address" value="${esc(c.address)}"></div>
    </div>
    <div class="field"><label>Notes</label><textarea id="c_notes">${esc(c.notes)}</textarea></div>
  `,`
    <button class="btn" value="cancel">Cancel</button>
    <button class="btn primary" id="saveClient">Save</button>
  `);

  document.getElementById("saveClient").onclick=()=>{
    c.name=document.getElementById("c_name").value.trim();
    c.owner=document.getElementById("c_owner").value.trim();
    c.whatsapp=document.getElementById("c_whatsapp").value.trim();
    c.phone=document.getElementById("c_phone").value.trim();
    c.address=document.getElementById("c_address").value.trim();
    c.notes=document.getElementById("c_notes").value.trim();
    if(!c.name) return alert("Shop name is required.");
    if(isEdit) state.clients=state.clients.map(x=>x.id===c.id?c:x); else state.clients.unshift(c);
    poSave(state); $dlg.close(); render();
  };
}

function openVisitDialog(visit){
  if(state.clients.length===0) return alert("Add a client first.");
  const isEdit=!!visit?.id;
  const v=visit?structuredClone(visit):{
    id:uid("v"), createdAt:Date.now(), date:todayISO(), time:"",
    clientId:state.clients[0].id, type:"Stock Check", status:"draft",
    total:0, invoiceNotes:"", notes:"", checklist:defaultChecklist()
  };

  openDlg(isEdit?"Open visit":"New visit",`
    <div class="row">
      <div class="field" style="flex:1"><label>Date</label><input id="v_date" type="date" value="${esc(v.date)}"></div>
      <div class="field" style="flex:1"><label>Time</label><input id="v_time" type="time" value="${esc(v.time)}"></div>
      <div class="field" style="flex:2"><label>Client</label>
        <select id="v_client">
          ${state.clients.map(c=>`<option value="${c.id}" ${c.id===v.clientId?"selected":""}>${esc(c.name)}</option>`).join("")}
        </select>
      </div>
    </div>

    <div class="row">
      <div class="field" style="flex:1"><label>Type</label>
        <select id="v_type">${["Stock Check","Maintenance","Both"].map(t=>`<option ${t===v.type?"selected":""}>${t}</option>`).join("")}</select>
      </div>
      <div class="field" style="flex:1"><label>Status</label>
        <select id="v_status">${["draft","done","sent","paid"].map(s=>`<option value="${s}" ${s===v.status?"selected":""}>${s.toUpperCase()}</option>`).join("")}</select>
      </div>
      <div class="field" style="flex:1"><label>Total (Invoice)</label><input id="v_total" type="number" step="0.01" value="${esc(v.total)}"></div>
    </div>

    <div class="field"><label>Visit notes</label><textarea id="v_notes">${esc(v.notes||"")}</textarea></div>

    <div class="hr"></div>
    <h3 style="margin:0 0 6px;font-size:15px">Detailed checklist</h3>
    <div class="notice">Tap OK / RISK / CRITICAL. Add notes for evidence.</div>
    <div id="clWrap" style="margin-top:10px"></div>

    <div class="field"><label>Invoice notes (optional)</label><textarea id="v_invoiceNotes">${esc(v.invoiceNotes||"")}</textarea></div>
  `,`
    <button class="btn" value="cancel">Cancel</button>
    <button class="btn primary" id="saveVisit">Save</button>
  `);

  document.getElementById("clWrap").innerHTML = renderChecklist(v);
  wireChecklist(v);

  document.getElementById("saveVisit").onclick=()=>{
    v.date=document.getElementById("v_date").value;
    v.time=document.getElementById("v_time").value;
    v.clientId=document.getElementById("v_client").value;
    v.type=document.getElementById("v_type").value;
    v.status=document.getElementById("v_status").value;
    v.total=Number(document.getElementById("v_total").value||0);
    v.notes=document.getElementById("v_notes").value.trim();
    v.invoiceNotes=document.getElementById("v_invoiceNotes").value.trim();
    if(isEdit) state.visits=state.visits.map(x=>x.id===v.id?v:x); else state.visits.unshift(v);
    poSave(state); selectedVisitId=v.id; $dlg.close(); render();
  };
}

function renderChecklist(v){
  const r=calcRisk(v);
  return `
    <div class="pills">${badgeRisk(r)} <span class="muted">(${r.points}/${r.max})</span></div>
    <div class="hr"></div>
    ${CHECKLIST.map(sec=>{
      const st=v.checklist?.[sec.key]?.status||"ok";
      const note=v.checklist?.[sec.key]?.note||"";
      return `
        <div class="card" style="margin-bottom:10px">
          <div><strong>${esc(sec.label)}</strong></div>
          <div class="choice" data-sec="${sec.key}">
            <button type="button" data-val="ok" class="${st==="ok"?"active":""}">OK</button>
            <button type="button" data-val="risk" class="${st==="risk"?"active":""}">RISK</button>
            <button type="button" data-val="crit" class="${st==="crit"?"active":""}">CRITICAL</button>
          </div>
          <div class="field" style="margin:10px 0 0">
            <label>Notes / evidence</label>
            <textarea data-note="${sec.key}">${esc(note)}</textarea>
          </div>
        </div>
      `;
    }).join("")}
  `;
}
function wireChecklist(v){
  $dlgBody.querySelectorAll(".choice").forEach(w=>{
    const key=w.dataset.sec;
    w.querySelectorAll("button[data-val]").forEach(btn=>{
      btn.onclick=()=>{
        v.checklist[key].status=btn.dataset.val;
        document.getElementById("clWrap").innerHTML=renderChecklist(v);
        wireChecklist(v);
      };
    });
  });
  $dlgBody.querySelectorAll("textarea[data-note]").forEach(t=>{
    t.oninput=()=>{ v.checklist[t.dataset.note].note=t.value; };
  });
}

function openTicketDialog(ticket){
  if(state.clients.length===0) return alert("Add a client first.");
  const isEdit=!!ticket?.id;
  const t=ticket?structuredClone(ticket):{
    id:uid("t"), createdAt:Date.now(), clientId:state.clients[0].id,
    title:"", notes:"", priority:"Medium", quote:0, status:"open"
  };

  openDlg(isEdit?"Open ticket":"New ticket",`
    <div class="row">
      <div class="field" style="flex:2"><label>Client</label>
        <select id="t_client">
          ${state.clients.map(c=>`<option value="${c.id}" ${c.id===t.clientId?"selected":""}>${esc(c.name)}</option>`).join("")}
        </select>
      </div>
      <div class="field" style="flex:1"><label>Priority</label>
        <select id="t_pri">${["Low","Medium","High"].map(p=>`<option ${p===t.priority?"selected":""}>${p}</option>`).join("")}</select>
      </div>
      <div class="field" style="flex:1"><label>Status</label>
        <select id="t_status">${["open","quoted","approved","done"].map(s=>`<option value="${s}" ${s===t.status?"selected":""}>${s.toUpperCase()}</option>`).join("")}</select>
      </div>
    </div>

    <div class="field"><label>Task</label><input id="t_title" value="${esc(t.title)}" placeholder="Fix cage lock / Replace lights / Repair door"></div>
    <div class="field"><label>Quote (R)</label><input id="t_quote" type="number" step="0.01" value="${esc(t.quote)}"></div>
    <div class="field"><label>Notes</label><textarea id="t_notes">${esc(t.notes||"")}</textarea></div>
  `,`
    <button class="btn" value="cancel">Cancel</button>
    <button class="btn primary" id="saveTicket">Save</button>
  `);

  document.getElementById("saveTicket").onclick=()=>{
    t.clientId=document.getElementById("t_client").value;
    t.priority=document.getElementById("t_pri").value;
    t.status=document.getElementById("t_status").value;
    t.title=document.getElementById("t_title").value.trim();
    t.quote=Number(document.getElementById("t_quote").value||0);
    t.notes=document.getElementById("t_notes").value.trim();
    if(!t.title) return alert("Task title is required.");
    if(isEdit) state.tickets=state.tickets.map(x=>x.id===t.id?t:x); else state.tickets.unshift(t);
    poSave(state); $dlg.close(); render();
  };
}

function openRetainerDialog(ret){
  if(state.clients.length===0) return alert("Add a client first.");
  const isEdit=!!ret?.id;
  const r=ret?structuredClone(ret):{
    id:uid("r"), createdAt:Date.now(), clientId:state.clients[0].id,
    plan:"Monthly Control", monthly:0, nextDate:""
  };

  openDlg(isEdit?"Edit retainer":"New retainer",`
    <div class="field"><label>Client</label>
      <select id="r_client">
        ${state.clients.map(c=>`<option value="${c.id}" ${c.id===r.clientId?"selected":""}>${esc(c.name)}</option>`).join("")}
      </select>
    </div>

    <div class="row">
      <div class="field" style="flex:2"><label>Plan name</label><input id="r_plan" value="${esc(r.plan)}"></div>
      <div class="field" style="flex:1"><label>Monthly fee (R)</label><input id="r_monthly" type="number" step="0.01" value="${esc(r.monthly)}"></div>
    </div>

    <div class="field"><label>Next visit date (optional)</label><input id="r_next" type="date" value="${esc(r.nextDate||"")}"></div>

    <div class="notice">Pitch: “I come back monthly, keep risk LOW, and handle maintenance follow-ups.”</div>
  `,`
    <button class="btn" value="cancel">Cancel</button>
    <button class="btn primary" id="saveRet">Save</button>
  `);

  document.getElementById("saveRet").onclick=()=>{
    r.clientId=document.getElementById("r_client").value;
    r.plan=document.getElementById("r_plan").value.trim() || "Monthly Control";
    r.monthly=Number(document.getElementById("r_monthly").value||0);
    r.nextDate=document.getElementById("r_next").value;
    if(isEdit) state.retainers=state.retainers.map(x=>x.id===r.id?r:x); else state.retainers.unshift(r);
    poSave(state); $dlg.close(); render();
  };
}
