// Prospect Ops storage (localStorage) — Upgrade v2
const PO_STORAGE_KEY = "prospect_ops_upgrade_v2";

function poLoad() {
  try {
    const raw = localStorage.getItem(PO_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { clients: [], visits: [], tickets: [], retainers: [] };
}

function poSave(state) {
  localStorage.setItem(PO_STORAGE_KEY, JSON.stringify(state));
}

function poExport(state) {
  return {
    exportedAt: new Date().toISOString(),
    app: "Prospect Ops",
    version: "upgrade-v2",
    state
  };
}

function poImport(obj) {
  if (!obj || !obj.state) throw new Error("Invalid backup");
  const s = obj.state;
  if (!Array.isArray(s.clients) || !Array.isArray(s.visits)) throw new Error("Invalid backup");
  s.tickets = Array.isArray(s.tickets) ? s.tickets : [];
  s.retainers = Array.isArray(s.retainers) ? s.retainers : [];
  return s;
}
